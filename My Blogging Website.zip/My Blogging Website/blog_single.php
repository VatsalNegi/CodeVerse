<?php
include 'partials/header.php';
include 'includes/db.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  echo "<h2 style='text-align:center;'>Invalid blog ID.</h2>";
  include 'partials/footer.php';
  exit();
}

$blog_id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT posts.*, users.name AS author FROM posts JOIN users ON posts.user_id = users.id WHERE posts.id = ? AND status = 'approved'");
$stmt->bind_param("i", $blog_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "<h2 style='text-align:center;'>Blog not found or not approved.</h2>";
  include 'partials/footer.php';
  exit();
}

$blog = $result->fetch_assoc();
?>

<link rel="stylesheet" href="css/blog_single.css">
<title><?= htmlspecialchars($blog['title']) ?> - CodeVerse</title>

<section class="single__blog__wrapper">
  <div class="container">
    <h1 class="blog__title"><?= htmlspecialchars($blog['title']) ?></h1>
    <p class="blog__meta">By <strong><?= htmlspecialchars($blog['author']) ?></strong> • <?= date('F j, Y', strtotime($blog['created_at'])) ?></p>
    <div class="blog__content">
      <?= nl2br(htmlspecialchars($blog['content'])) ?>
    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>
