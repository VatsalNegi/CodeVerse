<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Welcome to The Code Verse</title>
  <link rel="icon" type="image/png" href="/My%20Blogging%20Website/Images/favicon.png">
  <link rel="stylesheet" href="/My Blogging Website/css/header.css">
  <link rel="stylesheet" href="/My Blogging Website/css/footer.css">
  <link href="https://unicons.iconscout.com/release/v4.0.0/css/line.css" rel="stylesheet" />
</head>
<body>
  <header class="site__header">
    <div class="container nav__container">
      <h2 class="logo"><a href="index.php">CodeVerse</a></h2>
      <nav class="nav__links">
        <a href="/My Blogging Website/index.php"><i class="uil uil-estate"></i> Home</a>
        <a href="/My Blogging Website/about.php"><i class="uil uil-user"></i> About</a>
        <a href="/My Blogging Website/categories.php"><i class="uil uil-apps"></i> Category</a>
        <a href="/My Blogging Website/login.php"><i class="uil uil-envelope"></i> Login</a>
        <a href="/My Blogging Website/join.php"><i class="uil uil-user-plus"></i> Join as Creator</a>
      </nav>
    </div>
  </header>
