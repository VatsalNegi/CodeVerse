<footer class="footer">
  <div class="footer-container">
    <div class="footer-section">
      <h4>Connect With Us</h4>
      <div class="social-icons">
        <a href="https://www.linkedin.com/in/codex-club-tmu2025/" target="_blank"><i class="uil uil-linkedin-alt"></i></a>
        <a href="https://github.com/VatsalNegi" target="_blank"><i class="uil uil-github-alt"></i></a>
        <a href="https://codexclub13@gmail.com"><i class="uil uil-envelope"></i></a>
        <a href="https://www.instagram.com/codex_tmu?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" target="_blank"><i class="uil uil-instagram"></i></a>
      </div>
    </div>
    <div class="footer-note">
      <p>&copy; <?= date('Y') ?> The Code Verse. All rights reserved.</p>
    </div>
  </div>
</footer>
