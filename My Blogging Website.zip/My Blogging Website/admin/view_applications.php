<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
  header("Location: ../login.php");
  exit();
}

include '../includes/db.php';
include '../partials/header.php';

// Filter logic
$statusFilter = $_GET['status'] ?? 'all';
if ($statusFilter !== 'all') {
  $stmt = $conn->prepare("SELECT * FROM creator_applications WHERE status = ? ORDER BY submitted_at DESC");
  $stmt->bind_param("s", $statusFilter);
  $stmt->execute();
  $result = $stmt->get_result();
} else {
  $result = $conn->query("SELECT * FROM creator_applications ORDER BY submitted_at DESC");
}
?>

<link rel="stylesheet" href="../css/applications.css">

<section class="applications__wrapper">
  <div class="container">
    <h1>📥 Creator Applications</h1>

  <div class="filter__tabs">
   <a href="?status=all" class="<?php echo (!isset($_GET['status']) || $_GET['status'] === 'all') ? 'active' : ''; ?>">All</a>
  <a href="?status=pending" class="<?php echo (isset($_GET['status']) && $_GET['status'] === 'pending') ? 'active' : ''; ?>">Pending</a>
  <a href="?status=approved" class="<?php echo (isset($_GET['status']) && $_GET['status'] === 'approved') ? 'active' : ''; ?>">Approved</a>
  <a href="?status=rejected" class="<?php echo (isset($_GET['status']) && $_GET['status'] === 'rejected') ? 'active' : ''; ?>">Rejected</a>
  </div>


    <?php if ($result->num_rows > 0): ?>
      <div class="applications__grid">
        <?php while ($row = $result->fetch_assoc()): ?>
          <div class="application__card">
            <h3><?= htmlspecialchars($row['name']) ?></h3>
            <p><strong>Email:</strong> <?= htmlspecialchars($row['email']) ?></p>
            <?php if (!empty($row['linkedin'])): ?>
              <p><strong>LinkedIn:</strong> <a href="<?= htmlspecialchars($row['linkedin']) ?>" target="_blank">View Profile</a></p>
            <?php endif; ?>
            <p><strong>Interest:</strong> <?= htmlspecialchars($row['interest']) ?></p>
            <p><strong>Message:</strong> <?= nl2br(htmlspecialchars($row['message'])) ?></p>
            <p class="timestamp">Submitted on <?= date('F j, Y, g:i a', strtotime($row['submitted_at'])) ?></p>
            <p><strong>Status:</strong> <span class="status <?= $row['status'] ?>"><?= ucfirst($row['status']) ?></span></p>

            <?php if ($row['status'] === 'pending'): ?>
              <form action="handle_application.php" method="POST">
                <input type="hidden" name="app_id" value="<?= $row['id'] ?>">
                <button name="action" value="approve" class="btn approve">✅ Approve</button>
                <button name="action" value="reject" class="btn reject">❌ Reject</button>
              </form>
            <?php endif; ?>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p>No applications found.</p>
    <?php endif; ?>
  </div>
</section>

<?php include '../partials/footer.php'; ?>
