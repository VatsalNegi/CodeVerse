<?php
include '../includes/db.php';
include '../includes/admin_check.php';

if (isset($_GET['id']) && isset($_GET['action'])) {
  $id = intval($_GET['id']);
  $action = $_GET['action'];

  if ($action === 'approve') {
    $stmt = $conn->prepare("UPDATE posts SET status = 'approved' WHERE id = ?");
  } elseif ($action === 'reject') {
    $stmt = $conn->prepare("UPDATE posts SET status = 'rejected' WHERE id = ?");
  }

  if ($stmt) {
    $stmt->bind_param("i", $id);
    $stmt->execute();
  }
}

header("Location: dashboard.php");
exit();
