<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
  header("Location: ../login.php");
  exit();
}

include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['app_id'], $_POST['action'])) {
  $app_id = intval($_POST['app_id']);
  $action = $_POST['action'];

  if (!in_array($action, ['approve', 'reject'])) {
    $_SESSION['error'] = "Invalid action.";
    header("Location: view_applications.php");
    exit();
  }

  if ($action === 'approve') {
    // ✅ Update application status
    $updateStmt = $conn->prepare("UPDATE creator_applications SET status = 'approved' WHERE id = ?");
    if (!$updateStmt) {
      die("❌ Update prepare failed: " . $conn->error);
    }
    $updateStmt->bind_param("i", $app_id);
    $updateStmt->execute();

    // ✅ Fetch approved applicant's data
    $stmt = $conn->prepare("SELECT name, email, password FROM creator_applications WHERE id = ?");
    if (!$stmt) {
      die("❌ Select prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $app_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $applicant = $result->fetch_assoc();

    if ($applicant) {
      // ✅ Check if already exists
      $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
      if (!$check) {
        die("❌ Check prepare failed: " . $conn->error);
      }
      $check->bind_param("s", $applicant['email']);
      $check->execute();
      $check_result = $check->get_result();

      if ($check_result->num_rows === 0) {
        // ✅ Insert into users table
        $insert = $conn->prepare("INSERT INTO users (name, email, password, is_admin) VALUES (?, ?, ?, 0)");
        if (!$insert) {
          die("❌ Insert prepare failed: " . $conn->error);
        }
        $insert->bind_param("sss", $applicant['name'], $applicant['email'], $applicant['password']);
        $insert->execute();
      }
    }

    $_SESSION['success'] = "✅ Application approved and user account created.";
  }

  if ($action === 'reject') {
    $stmt = $conn->prepare("UPDATE creator_applications SET status = 'rejected' WHERE id = ?");
    if (!$stmt) {
      die("❌ Reject prepare failed: " . $conn->error);
    }
    $stmt->bind_param("i", $app_id);
    $stmt->execute();

    $_SESSION['success'] = "❌ Application rejected.";
  }
}

header("Location: view_applications.php");
exit();
