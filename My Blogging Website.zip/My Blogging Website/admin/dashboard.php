<?php 
include '../includes/db.php';
include '../includes/admin_check.php';
?>
<?php include '../partials/header.php'; ?>
<link rel="stylesheet" href="../css/admin.css">
<title>Admin Dashboard - CodeVerse</title>

<section class="admin__wrapper">
  <div class="admin__container">

    <!-- ✅ Dashboard Header with Profile Button -->
    <div class="dashboard__topbar">
  <h1>📑 Pending Blog Posts</h1>
  <a href="../user/profile.php" class="profile__btn">✍️ Go to Profile</a>
  <a href="view_applications.php" class="profile__btn">📥 View Applications</a>
  </div>

    <?php
    $query = "SELECT posts.id, posts.title, posts.content, posts.created_at, users.name AS author
              FROM posts
              JOIN users ON posts.user_id = users.id
              WHERE posts.status = 'pending'
              ORDER BY posts.created_at DESC";

    $result = $conn->query($query);

    if ($result->num_rows > 0): ?>
      <div class="post__list">
        <?php while ($post = $result->fetch_assoc()): ?>
          <div class="post__card">
            <h3><?= htmlspecialchars($post['title']) ?></h3>
            <p class="meta">By <?= htmlspecialchars($post['author']) ?> | <?= date('M j, Y', strtotime($post['created_at'])) ?></p>
            <p class="snippet"><?= nl2br(htmlspecialchars(substr($post['content'], 0, 200))) ?>...</p>
            <div class="actions">
              <a href="approve_post.php?id=<?= $post['id'] ?>&action=approve" class="btn approve">✅ Approve</a>
              <a href="approve_post.php?id=<?= $post['id'] ?>&action=reject" class="btn reject">❌ Reject</a>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p>No pending posts right now.</p>
    <?php endif; ?>

  </div>
</section>

<?php include '../partials/footer.php'; ?>
