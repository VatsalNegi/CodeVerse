<?php
include 'includes/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name']);
  $email = trim($_POST['email']);
  $linkedin = trim($_POST['linkedin']);
  $interest = trim($_POST['interest']);
  $message = trim($_POST['message']);
  $password = $_POST['password'];
  $confirm_password = $_POST['confirm_password'];

  if ($password !== $confirm_password) {
    $_SESSION['error'] = "Passwords do not match!";
  } else {
    $hashed = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO creator_applications (name, email, password, linkedin, interest, message) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $name, $email, $hashed, $linkedin, $interest, $message);
    $stmt->execute();

    $_SESSION['success'] = "✅ Application submitted successfully. You'll be notified after approval.";
    header("Location: join.php");
    exit();
  }
}
?>

<?php include 'partials/header.php'; ?>
<link rel="stylesheet" href="css/join.css" />

<section class="join__section">
  <div class="join__container">

    <!-- Left Info Section -->
    <div class="join__info">
      <h1>Become a Creator @<span>The Code Verse</span></h1>
      <p>Are you passionate about technology, development, or design? Want to showcase your ideas to the world? <strong>The Code Verse</strong> invites creators, writers, and tech enthusiasts to contribute their knowledge across diverse fields like:</p>

      <ul>
        <li><i class="uil uil-arrow-circle-right"></i> Web Development & Design</li>
        <li><i class="uil uil-arrow-circle-right"></i> Data Science, AI & ML</li>
        <li><i class="uil uil-arrow-circle-right"></i> Prompt Engineering</li>
        <li><i class="uil uil-arrow-circle-right"></i> Blockchain & Cloud</li>
        <li><i class="uil uil-arrow-circle-right"></i> Cybersecurity & Testing</li>
      </ul>

      <p class="highlight">💡 Share your knowledge and get featured on our platform. Let's grow together!</p>
    </div>

    <!-- Right Form Section -->
    <div class="join__form">
      <h3>Apply Now</h3>

      <?php if (isset($_SESSION['error'])): ?>
        <p style="color: #ff4d4d;"><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
      <?php endif; ?>

      <?php if (isset($_SESSION['success'])): ?>
        <p style="color: #24b464;"><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
      <?php endif; ?>

      <form action="join.php" method="POST">
        <div class="form__control">
          <label for="name">Full Name</label>
          <input type="text" id="name" name="name" required />
        </div>

        <div class="form__control">
          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" required />
        </div>

        <div class="form__control">
          <label for="password">Create Password</label>
          <input type="password" id="password" name="password" required placeholder="Choose a password" />
        </div>

        <div class="form__control">
          <label for="confirm_password">Confirm Password</label>
          <input type="password" id="confirm_password" name="confirm_password" required placeholder="Re-enter password" />
        </div>

        <div class="form__control">
          <label for="linkedin">LinkedIn / Portfolio (Optional)</label>
          <input type="text" id="linkedin" name="linkedin" />
        </div>

        <div class="form__control">
          <label for="interest">Your Domain of Interest</label>
          <input type="text" id="interest" name="interest" placeholder="e.g. AI, Web Dev, Cloud..." required />
        </div>

        <div class="form__control">
          <label for="message">Why do you want to join?</label>
          <textarea id="message" name="message" rows="4" placeholder="Tell us what drives your interest..." required></textarea>
        </div>

        <button type="submit" class="btn join__btn">Submit Application</button>
      </form>
    </div>

  </div>
</section>

<?php include 'partials/footer.php'; ?>
