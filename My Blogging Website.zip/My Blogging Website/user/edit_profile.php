<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit();
}

include '../includes/db.php';

$user_id = $_SESSION['user_id'];

// Get user data
$stmt = $conn->prepare("SELECT name, email, profile_pic FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Update profile info
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
  $new_name = trim($_POST['name']);
  $new_email = trim($_POST['email']);

  // Upload profile photo if available
  if ($_FILES['profile_pic']['name']) {
    $target_dir = "../uploads/";
    if (!is_dir($target_dir)) mkdir($target_dir);
    
    $filename = time() . "_" . basename($_FILES["profile_pic"]["name"]);
    $target_file = $target_dir . $filename;
    move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file);

    $update = $conn->prepare("UPDATE users SET name=?, email=?, profile_pic=? WHERE id=?");
    $update->bind_param("sssi", $new_name, $new_email, $filename, $user_id);
  } else {
    $update = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
    $update->bind_param("ssi", $new_name, $new_email, $user_id);
  }

  $update->execute();
  $_SESSION['name'] = $new_name;
  header("Location: profile.php");
  exit();
}

// Change password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
  $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
  $update_pass = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
  $update_pass->bind_param("si", $new_password, $user_id);
  $update_pass->execute();
  $success = "Password updated successfully!";
}

// Delete blog
if (isset($_GET['delete_post'])) {
  $post_id = intval($_GET['delete_post']);
  $del_stmt = $conn->prepare("DELETE FROM posts WHERE id = ? AND user_id = ?");
  $del_stmt->bind_param("ii", $post_id, $user_id);
  $del_stmt->execute();
}

// Fetch blogs
$post_query = $conn->prepare("SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC");
$post_query->bind_param("i", $user_id);
$post_query->execute();
$posts = $post_query->get_result();
?>

<?php include '../partials/header.php'; ?>
<link rel="stylesheet" href="../css/profile.css">
<title>Edit Profile - CodeVerse</title>

<section class="profile__wrapper">
  <div class="profile__container">
    <h1>⚙️ Edit Your Profile</h1>

    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

    <!-- Profile form -->
    <form method="POST" enctype="multipart/form-data" class="edit__form">
      <div class="form__group">
        <label>Full Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
      </div>

      <div class="form__group">
        <label>Email Address</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
      </div>

      <div class="form__group">
        <label>Profile Photo (optional)</label>
        <input type="file" name="profile_pic">
        <?php if ($user['profile_pic']): ?>
          <img src="../uploads/<?= $user['profile_pic'] ?>" width="80" style="margin-top:10px;border-radius:50%;">
        <?php endif; ?>
      </div>

      <button type="submit" name="update_profile" class="create__btn">💾 Update Profile</button>
    </form>

    <hr style="margin: 2rem 0; border-color: #444;">

    <!-- Password Change -->
    <form method="POST" class="edit__form">
      <h3>🔐 Change Password</h3>
      <div class="form__group">
        <label>New Password</label>
        <input type="password" name="new_password" required>
      </div>
      <button type="submit" name="change_password" class="create__btn">Update Password</button>
    </form>

    <hr style="margin: 2rem 0; border-color: #444;">

    <!-- Blog List -->
    <h2>Your Blogs</h2>
    <?php if ($posts->num_rows > 0): ?>
      <?php while ($post = $posts->fetch_assoc()): ?>
        <div class="user__post">
          <h3><?= htmlspecialchars($post['title']) ?></h3>
          <p>Status: <strong class="<?= $post['status'] ?>"><?= ucfirst($post['status']) ?></strong></p>
          <p><?= nl2br(htmlspecialchars(substr($post['content'], 0, 150))) ?>...</p>
          <a href="edit_profile.php?delete_post=<?= $post['id'] ?>" style="color: red;" onclick="return confirm('Are you sure you want to delete this post?')">❌ Delete</a>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No blogs found.</p>
    <?php endif; ?>
  </div>
</section>

<?php include '../partials/footer.php'; ?>
