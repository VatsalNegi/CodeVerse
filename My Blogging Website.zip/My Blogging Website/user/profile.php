<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit();
}

include '../includes/db.php';

$user_id = $_SESSION['user_id'];

// Get user name
$stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get user's posts
$post_query = $conn->prepare("SELECT * FROM posts WHERE user_id = ? ORDER BY created_at DESC");
$post_query->bind_param("i", $user_id);
$post_query->execute();
$posts = $post_query->get_result();
?>

<?php include '../partials/header.php'; ?>
<link rel="stylesheet" href="../css/profile.css">
<title>Your Dashboard - CodeVerse</title>

<section class="profile__wrapper">
  <div class="profile__container">
    <h1>Welcome, <?= htmlspecialchars($user['name']) ?> 👋</h1>

    <!-- ✅ Navigation Buttons -->
    <div class="dashboard__nav">
      <a href="edit_profile.php" class="dash__btn">👤 Profile</a>
      <a href="create_post.php" class="dash__btn">➕ Create Blog</a>
      <a href="../login.php" class="dash__btn logout">🔓 Logout</a>
    </div>

    <!-- ✅ Success Message -->
    <?php if (isset($_SESSION['success'])): ?>
      <p style="color: #28a745;"><?= $_SESSION['success']; unset($_SESSION['success']); ?></p>
    <?php endif; ?>

    <h2>Your Posts</h2>

    <?php if ($posts->num_rows > 0): ?>
      <?php while ($post = $posts->fetch_assoc()): ?>
        <div class="user__post">
          <h3><?= htmlspecialchars($post['title']) ?></h3>
          <p>Status: 
            <strong class="<?= $post['status'] ?>">
              <?= ucfirst($post['status']) ?>
            </strong>
          </p>
          <p><?= nl2br(htmlspecialchars(substr($post['content'], 0, 150))) ?>...</p>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>You haven’t posted anything yet. Click above to get started!</p>
    <?php endif; ?>
  </div>
</section>


<?php include '../partials/footer.php'; ?>
