<?php
session_start();
if (!isset($_SESSION['user_id'])) {
  header("Location: ../login.php");
  exit();
}

include '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = trim($_POST['title']);
  $content = trim($_POST['content']);
  $category = $_POST['category'];
  $user_id = $_SESSION['user_id'];
  $status = ($_SESSION['is_admin'] == 1) ? 'approved' : 'pending';

  $stmt = $conn->prepare("INSERT INTO posts (title, content, category, user_id, status) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("sssis", $title, $content, $category, $user_id, $status);
  $stmt->execute();

  $_SESSION['success'] = "✅ Blog submitted successfully!";
  header("Location: profile.php");
  exit();
}
?>

<?php include '../partials/header.php'; ?>
<link rel="stylesheet" href="../css/join.css"> <!-- Reusing the red-black join form styling -->
<title>Create Blog - CodeVerse</title>

<section class="join__section">
  <div class="join__container">

    <div class="join__info">
      <h1>Write a Blog <span>for CodeVerse</span></h1>
      <p>Share your knowledge with the world. Whether it's code, AI, cloud, or tech trends — your voice matters!</p>
    </div>

    <div class="join__form">
      <h3>New Blog Post</h3>
      <form action="" method="POST">
        <div class="form__control">
          <label for="title">Blog Title</label>
          <input type="text" name="title" id="title" required placeholder="Enter blog title">
        </div>

        <div class="form__control">
          <label for="category">Select Category</label>
          <select name="category" id="category" required>
            <option value="">-- Choose Category --</option>
            <option value="webdev">Web Development</option>
            <option value="design">Web Designing</option>
            <option value="datascience">Data Science</option>
            <option value="ai">AI / ML</option>
            <option value="cloud">Cloud Computing</option>
            <option value="blockchain">Blockchain</option>
            <option value="testing">Testing</option>
            <option value="prompt">Prompt Engineering</option>
          </select>
        </div>

        <div class="form__control">
          <label for="content">Content</label>
          <textarea name="content" id="content" rows="8" required placeholder="Write your blog content..."></textarea>
        </div>

        <button type="submit" class="btn join__btn">📤 Publish Blog</button>
      </form>
    </div>
  </div>
</section>

<?php include '../partials/footer.php'; ?>
