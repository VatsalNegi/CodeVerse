<?php include 'partials/header.php'; ?> 
<link rel="stylesheet" href="css/about.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<section class="about__wrapper">
  <div class="container">
    <h1 class="about__title">Meet the Creators</h1>

    <div class="team__grid">

      <!-- Vatsal Negi -->
      <div class="team__member">
        <img src="images/vatsal.jpg" alt="Vatsal Negi" class="team__image">
        <h3>Vatsal Negi</h3>
        <div class="social-icons">
          <a href="https://www.instagram.com/vatsal.negi/" target="_blank"><i class="fab fa-instagram"></i></a>
          <a href="https://github.com/VatsalNegi" target="_blank"><i class="fab fa-github"></i></a>
          <a href="https://www.linkedin.com/in/vatsal-negi-3624a12b6/" target="_blank"><i class="fab fa-linkedin-in"></i></a>
        </div>
        <p class="role">Founder & Developer</p>
        <p class="desc">Vatsal is the driving force behind The Code Verse. He designed and developed the entire platform, focusing on both frontend beauty and backend logic.</p>
      </div>

      <!-- Yash Jain -->
      <div class="team__member">
        <img src="images/yash.jpg" alt="Yash Jain" class="team__image">
        <h3>Yash Jain</h3>
        <div class="social-icons">
          <a href="https://www.instagram.com/perfect_yash_/" target="_blank"><i class="fab fa-instagram"></i></a>
          <a href="https://github.com/yash343328" target="_blank"><i class="fab fa-github"></i></a>
          <a href="https://www.linkedin.com/in/yash-jain2003/" target="_blank"><i class="fab fa-linkedin-in"></i></a>
        </div>
        <p class="role">Co-Founder & Platform Engineer</p>
        <p class="desc">Yash Jain contributed creative ideas, managed content structuring, and helped shape the website’s direction and purpose to make it community focused.</p>
      </div>

    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>
