<?php include 'partials/header.php'; ?>
<link rel="stylesheet" href="css/join.css"> <!-- Reuse the red-black theme -->
<title>Login - CodeVerse</title>

<section class="join__section">
  <div class="join__container">
    <!-- Left Info Section -->
    <div class="join__info">
      <h1>Welcome Back to <span>CodeVerse</span></h1>
      <p>Whether you're an admin or a creator, log in to continue your journey. Share your blogs, manage content, or review submissions.</p>
      <p class="highlight">🔐 Secure login for creators & admins</p>
    </div>

    <!-- Right Form Section -->
    <div class="join__form">
      <h3>Sign In</h3>

      <?php session_start(); if (isset($_SESSION['error'])): ?>
        <p style="color: red; font-size: 0.9rem;"><?= $_SESSION['error']; unset($_SESSION['error']); ?></p>
      <?php endif; ?>

      <form action="login_process.php" method="POST">
        <div class="form__control">
          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" required placeholder="you@example.com" />
        </div>

        <div class="form__control">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" required placeholder="••••••••" />
        </div>

        <button type="submit" class="btn join__btn">Login</button>
      </form>
    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>
