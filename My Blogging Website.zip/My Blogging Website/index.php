<?php include 'partials/header.php'; ?>
<link rel="stylesheet" href="css/home.css">
<link rel="stylesheet" href="css/footer.css">

<section class="hero">
  <div class="container hero__content">
    <h1>Welcome to <span class="highlight">The Code Verse</span></h1>
    <p>Your gateway to blogs on Web Development, AI/ML, Cloud Computing, Data Science, Prompt Engineering & more!</p>
    <a href="categories.php" class="btn hero__btn">Explore Blogs</a>
  </div>
</section>

<section class="features">
  <div class="container">
    <h2 class="section__title">Why Choose Code Verse?</h2>
    <div class="features__grid">
      <div class="feature__box">
        <i class="uil uil-code-branch"></i>
        <h3>Tech-Focused</h3>
        <p>From Web Dev to Blockchain, dive into trending technologies.</p>
      </div>
      <div class="feature__box">
        <i class="uil uil-lightbulb-alt"></i>
        <h3>Learn & Grow</h3>
        <p>Read insightful articles, boost your knowledge & career.</p>
      </div>
      <div class="feature__box">
        <i class="uil uil-users-alt"></i>
        <h3>Community Driven</h3>
        <p>Connect, contribute, and grow with fellow coders and creators.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>
