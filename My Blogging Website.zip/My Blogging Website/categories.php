<?php include 'partials/header.php'; ?> 
<link rel="stylesheet" href="css/categories.css">
<title>Explore Categories - The Code Verse</title>

<section class="categories__section">
  <div class="container">
    <h1 class="section__title">Explore Categories</h1>
    <p class="section__subtitle">Dive into topics from Web Development to AI/ML, Blockchain, and beyond.</p>

    <div class="categories__grid">
      <a href="categories/webdev.php" class="category__card">
        <h3>Web Development</h3>
        <p>Master HTML, CSS, JavaScript, React, Node.js, and more.</p>
      </a>

      <a href="categories/design.php" class="category__card">
        <h3>Web Designing</h3>
        <p>Explore UI/UX, Figma, animations, and interactive web design.</p>
      </a>

      <a href="categories/datascience.php" class="category__card">
        <h3>Data Science</h3>
        <p>Get hands-on with Python, Pandas, NumPy, and visualizations.</p>
      </a>

      <a href="categories/ai.php" class="category__card">
        <h3>AI / ML</h3>
        <p>Understand algorithms, deep learning, neural networks, and tools.</p>
      </a>

      <a href="categories/cloud.php" class="category__card">
        <h3>Cloud Computing</h3>
        <p>Discover AWS, Azure, Google Cloud, and deployment practices.</p>
      </a>

      <a href="categories/blockchain.php" class="category__card">
        <h3>Blockchain</h3>
        <p>Learn about Ethereum, smart contracts, NFTs, and decentralization.</p>
      </a>

      <a href="categories/testing.php" class="category__card">
        <h3>Testing</h3>
        <p>Learn Manual & Automation Testing, Selenium, Postman, etc.</p>
      </a>

      <a href="categories/prompt.php" class="category__card">
        <h3>Prompt Engineering</h3>
        <p>Master how to write powerful prompts for ChatGPT & other LLMs.</p>
      </a>
    </div>
  </div>
</section>

<?php include 'partials/footer.php'; ?>
