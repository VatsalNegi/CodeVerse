<?php
$host = 'localhost';
$dbname = 'codeverse_db'; // change if your DB name is different
$user = 'root';
$pass = ''; // or 'your_password' if any

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
  die("Database connection failed: " . $conn->connect_error);
}
?>
