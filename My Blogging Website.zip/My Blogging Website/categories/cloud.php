<?php include '../partials/header.php'; ?>
<link rel="stylesheet" href="../css/categories.css">
<title>Cloud Computing Blogs - CodeVerse</title>

<?php
include '../includes/db.php';
$query = "SELECT posts.*, users.name AS author 
          FROM posts 
          JOIN users ON posts.user_id = users.id 
          WHERE posts.status = 'approved' AND posts.category = 'cloud' 
          ORDER BY posts.created_at DESC";
$result = $conn->query($query);
?>

<section class="categories__section">
  <div class="container">
    <h1 class="section__title">Cloud Computing Blogs</h1>
    <p class="section__subtitle">Master AWS, Azure, GCP, DevOps pipelines, containers, and deployment.</p>

    <div class="blogs__grid">
      <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
          <div class="blog__card">
            <h3><?= htmlspecialchars($row['title']) ?></h3>
            <p class="meta">By <?= htmlspecialchars($row['author']) ?> • <?= date('M j, Y', strtotime($row['created_at'])) ?></p>
            <p class="snippet"><?= nl2br(htmlspecialchars(substr($row['content'], 0, 160))) ?>...</p>
            <a href="../blog_single.php?id=<?= $row['id'] ?>" class="read__more">Read More →</a>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p class="no__blogs">No blogs found in this category yet.</p>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include '../partials/footer.php'; ?>
